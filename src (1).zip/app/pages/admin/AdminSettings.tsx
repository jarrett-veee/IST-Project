import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Button } from "../../components/ui/button";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Switch } from "../../components/ui/switch";
import { Separator } from "../../components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../../components/ui/tabs";
import { toast } from "sonner";
import { Globe, Zap, Shield } from "lucide-react";

export function AdminSettings() {
  const [seoSettings, setSeoSettings] = useState({
    metaTitleTemplate: "{pageTitle} - AthleteCore",
    defaultMetaDescription: "Premium athletic gear for peak performance",
    ogImage: "",
    twitterHandle: "@athletecore",
  });

  const [performanceSettings, setPerformanceSettings] = useState({
    enableCaching: true,
    imageLazyLoading: true,
    minifyAssets: true,
    cdnEnabled: false,
  });

  const handleSaveSEO = () => {
    toast.success("SEO settings saved successfully!");
  };

  const handleSavePerformance = () => {
    toast.success("Performance settings saved successfully!");
  };

  const performanceScore = 85;

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-gray-600 mt-1">Manage your store configuration and preferences</p>
      </div>

      <Tabs defaultValue="seo">
        <TabsList>
          <TabsTrigger value="seo">
            <Globe className="w-4 h-4 mr-2" />
            SEO
          </TabsTrigger>
          <TabsTrigger value="performance">
            <Zap className="w-4 h-4 mr-2" />
            Performance
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="w-4 h-4 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        {/* SEO Tab */}
        <TabsContent value="seo" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>SEO Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="metaTitleTemplate">Meta Title Template</Label>
                <Input
                  id="metaTitleTemplate"
                  value={seoSettings.metaTitleTemplate}
                  onChange={(e) =>
                    setSeoSettings({ ...seoSettings, metaTitleTemplate: e.target.value })
                  }
                  placeholder="{pageTitle} - {siteName}"
                />
                <p className="text-xs text-gray-500">
                  Use {"{pageTitle}"} and {"{siteName}"} as variables
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="defaultMetaDescription">Default Meta Description</Label>
                <Textarea
                  id="defaultMetaDescription"
                  value={seoSettings.defaultMetaDescription}
                  onChange={(e) =>
                    setSeoSettings({ ...seoSettings, defaultMetaDescription: e.target.value })
                  }
                  rows={3}
                  maxLength={160}
                />
                <p className="text-xs text-gray-500">
                  {seoSettings.defaultMetaDescription.length}/160 characters
                </p>
              </div>

              <Separator />

              <div className="space-y-2">
                <Label htmlFor="ogImage">Default Open Graph Image URL</Label>
                <Input
                  id="ogImage"
                  type="url"
                  value={seoSettings.ogImage}
                  onChange={(e) => setSeoSettings({ ...seoSettings, ogImage: e.target.value })}
                  placeholder="https://example.com/og-image.jpg"
                />
                <p className="text-xs text-gray-500">
                  Recommended size: 1200x630px
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="twitterHandle">Twitter Handle</Label>
                <Input
                  id="twitterHandle"
                  value={seoSettings.twitterHandle}
                  onChange={(e) =>
                    setSeoSettings({ ...seoSettings, twitterHandle: e.target.value })
                  }
                  placeholder="@athletecore"
                />
              </div>

              <Button onClick={handleSaveSEO}>Save SEO Settings</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Robots.txt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                rows={8}
                defaultValue={`User-agent: *\nAllow: /\n\nSitemap: https://athletecore.com/sitemap.xml`}
                className="font-mono text-sm"
              />
              <Button variant="outline">Update Robots.txt</Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Performance Tab */}
        <TabsContent value="performance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Performance Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-6">
                <div className="relative w-32 h-32">
                  <svg className="w-32 h-32 transform -rotate-90">
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      stroke="#e5e7eb"
                      strokeWidth="12"
                      fill="none"
                    />
                    <circle
                      cx="64"
                      cy="64"
                      r="56"
                      stroke="#3b82f6"
                      strokeWidth="12"
                      fill="none"
                      strokeDasharray={`${(performanceScore / 100) * 351.86} 351.86`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-3xl font-bold">{performanceScore}</span>
                  </div>
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-lg mb-2">Good Performance</h3>
                  <p className="text-sm text-gray-600 mb-4">
                    Your store is performing well. Continue optimizing for even better results.
                  </p>
                  <Button variant="outline">Run Performance Test</Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Performance Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="enableCaching">Enable Caching</Label>
                  <p className="text-sm text-gray-600">Cache static assets for faster load times</p>
                </div>
                <Switch
                  id="enableCaching"
                  checked={performanceSettings.enableCaching}
                  onCheckedChange={(checked) =>
                    setPerformanceSettings({ ...performanceSettings, enableCaching: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="imageLazyLoading">Image Lazy Loading</Label>
                  <p className="text-sm text-gray-600">Load images only when needed</p>
                </div>
                <Switch
                  id="imageLazyLoading"
                  checked={performanceSettings.imageLazyLoading}
                  onCheckedChange={(checked) =>
                    setPerformanceSettings({ ...performanceSettings, imageLazyLoading: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="minifyAssets">Minify CSS/JS</Label>
                  <p className="text-sm text-gray-600">Compress assets for smaller file sizes</p>
                </div>
                <Switch
                  id="minifyAssets"
                  checked={performanceSettings.minifyAssets}
                  onCheckedChange={(checked) =>
                    setPerformanceSettings({ ...performanceSettings, minifyAssets: checked })
                  }
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="cdnEnabled">CDN Integration</Label>
                  <p className="text-sm text-gray-600">Distribute content globally</p>
                </div>
                <Switch
                  id="cdnEnabled"
                  checked={performanceSettings.cdnEnabled}
                  onCheckedChange={(checked) =>
                    setPerformanceSettings({ ...performanceSettings, cdnEnabled: checked })
                  }
                />
              </div>

              <Button onClick={handleSavePerformance}>Save Performance Settings</Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Core Web Vitals</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">LCP</p>
                  <p className="text-2xl font-bold text-green-600">1.8s</p>
                  <p className="text-xs text-gray-500 mt-1">Good</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">FID</p>
                  <p className="text-2xl font-bold text-green-600">85ms</p>
                  <p className="text-xs text-gray-500 mt-1">Good</p>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <p className="text-sm text-gray-600 mb-1">CLS</p>
                  <p className="text-2xl font-bold text-yellow-600">0.12</p>
                  <p className="text-xs text-gray-500 mt-1">Needs Improvement</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Security Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-sm text-blue-800">
                <p className="font-semibold mb-1">Demo Mode</p>
                <p>
                  This is a demonstration website. In a production environment, you would have
                  options to configure SSL certificates, API keys, webhooks, and other security
                  settings here.
                </p>
              </div>

              <Separator />

              <div>
                <h4 className="font-semibold mb-2">Security Checklist</h4>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                      ✓
                    </div>
                    <span>SSL Certificate Enabled</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                      ✓
                    </div>
                    <span>Payment Gateway Secured</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                      ✓
                    </div>
                    <span>Data Encryption Active</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <div className="w-5 h-5 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                      ✓
                    </div>
                    <span>Regular Security Audits</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
