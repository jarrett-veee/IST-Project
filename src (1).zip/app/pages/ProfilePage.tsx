import { useAuth } from "../context/AuthContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { User, Mail, Shield } from "lucide-react";
import { Separator } from "../components/ui/separator";

export function ProfilePage() {
  const { user } = useAuth();

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-center text-gray-600">Please log in to view your profile.</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-3xl mx-auto space-y-6">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold">Account Settings</h1>
          <p className="text-gray-600">Manage your account information and preferences</p>
        </div>

        <Separator />

        {/* Account Details Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <User className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <CardTitle>Account Details</CardTitle>
                <CardDescription>Your personal account information</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-1">
                <label className="text-sm text-gray-500">Account Name</label>
                <p className="font-medium">{user.name}</p>
              </div>
              <div className="space-y-1">
                <label className="text-sm text-gray-500">Account ID</label>
                <p className="font-medium text-gray-600">{user.id}</p>
              </div>
              <div className="space-y-1">
                <label className="text-sm text-gray-500">Account Status</label>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                  <p className="font-medium text-green-600">Active</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Details Section */}
        <Card>
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Mail className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <CardTitle>Contact Details</CardTitle>
                <CardDescription>Your contact information</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-sm text-gray-500">Email Address</label>
                <p className="font-medium">{user.email}</p>
              </div>
              <div className="flex items-center gap-2 text-sm text-green-600 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                <Shield className="w-4 h-4" />
                <span>Email verified</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Account Statistics */}
        <Card>
          <CardHeader>
            <CardTitle>Account Statistics</CardTitle>
            <CardDescription>Your activity overview</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Member Since</p>
                <p className="text-2xl font-bold">2026</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Total Orders</p>
                <p className="text-2xl font-bold">0</p>
              </div>
              <div className="space-y-1">
                <p className="text-sm text-gray-500">Loyalty Points</p>
                <p className="text-2xl font-bold">0</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
