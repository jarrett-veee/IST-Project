import { Target, Users, Award, Heart } from "lucide-react";
import { Card, CardContent } from "../components/ui/card";

export function AboutPage() {
  const values = [
    {
      icon: Target,
      title: "Performance First",
      description:
        "We design every product with one goal: to help you perform at your best, whether you're training for a marathon or hitting the gym.",
    },
    {
      icon: Users,
      title: "Community Driven",
      description:
        "Our community of athletes inspires everything we do. We listen, learn, and create products that meet real needs.",
    },
    {
      icon: Award,
      title: "Quality Standards",
      description:
        "Premium materials, rigorous testing, and attention to detail ensure our products exceed expectations every time.",
    },
    {
      icon: Heart,
      title: "Sustainable Practices",
      description:
        "We're committed to reducing our environmental impact through sustainable materials and ethical manufacturing.",
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-gradient-to-br from-blue-600 to-blue-800 text-white py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Built by Athletes, for Athletes
            </h1>
            <p className="text-lg lg:text-xl text-blue-100">
              Since 2015, AthleteCore has been dedicated to creating premium athletic gear
              that empowers athletes of all levels to achieve their goals. Our mission is
              simple: provide the best performance equipment at accessible prices.
            </p>
          </div>
        </div>
      </section>

      {/* Story */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <div className="space-y-4 text-gray-700">
                <p>
                  AthleteCore was founded by Sarah Chen, a former Olympic runner who was
                  frustrated by the lack of high-quality, affordable athletic gear. After
                  retiring from competitive sports, she set out to create a brand that would
                  make professional-grade equipment accessible to everyone.
                </p>
                <p>
                  What started in a small warehouse with just five products has grown into a
                  global brand serving hundreds of thousands of athletes worldwide. But our
                  core values remain the same: quality, performance, and accessibility.
                </p>
                <p>
                  Today, we partner with top athletes, sports scientists, and designers to
                  create innovative products that help you train harder, recover faster, and
                  perform better.
                </p>
              </div>
            </div>
            <div className="relative h-96 rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&q=80"
                alt="Athletes training together"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              These principles guide everything we do, from product design to customer
              service.
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {values.map((value) => (
              <Card key={value.title}>
                <CardContent className="p-6 text-center space-y-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                    <value.icon className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-lg">{value.title}</h3>
                  <p className="text-sm text-gray-600">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl font-bold text-blue-600 mb-2">500K+</p>
              <p className="text-gray-600">Happy Athletes</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 mb-2">50+</p>
              <p className="text-gray-600">Countries Served</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 mb-2">1M+</p>
              <p className="text-gray-600">Products Sold</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-blue-600 mb-2">4.8</p>
              <p className="text-gray-600">Average Rating</p>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Meet Our Team</h2>
            <p className="text-lg text-gray-600">
              Passionate athletes and experts dedicated to your success
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Chen",
                role: "Founder & CEO",
                image: "https://images.unsplash.com/photo-1758600587839-56ba05596c69?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBhc2lhbiUyMHdvbWFuJTIwYnVzaW5lc3MlMjBoZWFkc2hvdHxlbnwxfHx8fDE3NzIwNjkxMzZ8MA&ixlib=rb-4.1.0&q=80&w=1080",
              },
              {
                name: "Marcus Johnson",
                role: "Head of Product",
                image: "https://images.unsplash.com/photo-1652471943570-f3590a4e52ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9mZXNzaW9uYWwlMjBibGFjayUyMG1hbiUyMGJ1c2luZXNzJTIwaGVhZHNob3R8ZW58MXx8fHwxNzcyMTM2NDY2fDA&ixlib=rb-4.1.0&q=80&w=1080",
              },
              {
                name: "Emily Rodriguez",
                role: "Lead Designer",
                image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&q=80",
              },
            ].map((member) => (
              <Card key={member.name}>
                <CardContent className="p-6 text-center">
                  <div className="w-32 h-32 mx-auto mb-4 rounded-full overflow-hidden">
                    <img
                      src={member.image}
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="font-semibold text-lg">{member.name}</h3>
                  <p className="text-gray-600">{member.role}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}